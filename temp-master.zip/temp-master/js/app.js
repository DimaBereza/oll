var data = {
	defaultLanguage: 'ua',
	dictionary:{
		en: {
			name: "Your name",
			namePlaceholder: "Input your name",
			gender: "Choose your gender",
			genderMale: "Male",
			genderFemale: "Female",
			countryWrapper: "Choose country where you live",
			countries: {
				ua: "Ukraine",
				fr: "France",
				us: "USA",
				br: "Brasil"
			},
			isShowBornCountry: "The country where you live and the country where you were born are the same?",
			bornCountryWrapper: "Choose country where you born",
			email:	"Your email",
			emailPlaceholder: "Input your email",
			buttonText: "Send"
		},
		ua: {
			name: "Ваше имя",
			namePlaceholder: "Введите ваше имя",
			gender: "Choose your gender",
			genderMale: "Male",
			genderFemale: "Female",
			countryWrapper: "Choose country where you live",
			countries: {
				ua: "Ukraine",
				fr: "France",
				us: "USA",
				br: "Brasil"
			},
			isShowBornCountry: "The country where you live and the country where you were born are the same?",
			bornCountryWrapper: "Choose country where you born",
			email:	"Your email",
			emailPlaceholder: "Input your email",
			buttonText: "Send"
		}
	}
}
$(".language-image").click(function(event) {
	currentLanguage = $(this).attr('data-lang')
	$(".language-image").removeClass('active')
	$(this).addClass('active');
	console.log(currentLanguage)
});

function setFormValue(){
	var dict = data.dictionary[currentLanguage]
	$("#name .description").text(dict.name);
	$("#name input").attr('placeholder', dict.namePlaceholder)
}

var currentLanguage = data.defaultLanguage;
setFormValue();